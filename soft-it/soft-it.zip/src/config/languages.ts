export default [
  { label: 'English', value: 'en' },
  { label: 'Русский', value: 'ru' },
  { label: 'O\'zbek', value: 'uz' }
];