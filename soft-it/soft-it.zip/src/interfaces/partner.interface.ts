export interface IPartner {
  id: number;
  title: string;
  link: string;
  image_url: string;
}